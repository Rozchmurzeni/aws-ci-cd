export const environment = {
  production: false,
  loanOffererApiBaseUrl: "<YOUR_API_URL>",
  loanOffererApiKey: "<YOUR_API_KEY>"
};